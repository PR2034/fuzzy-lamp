namespace CheatState
{
    extern bool enable_recoil;
    extern bool show_esplines;
    extern bool show_espboxes;
    extern bool show_espinfo;
    extern bool enable_circleFov;
    extern bool stream_mode;
    extern bool show_esp;
    extern bool hide_top_label;
    extern bool enable_aimbot; // Add this line
    extern bool enable_bullet_tracking; // Add this line for bullet tracking
    extern int aimAssistPosition;
    extern int circleSizeValue;
    extern int distanceValue;
    extern int style_idx;
    extern int aim_target; // Add this line
    extern int aim_location; // Add this line
    extern int aim_trigger; // Add this line
    extern float colorEsp[3];
}
