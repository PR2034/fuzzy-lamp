namespace CheatState
{
    bool enable_recoil = false;
    bool show_esplines = false;
    bool show_espboxes = false;
    bool show_espinfo = false;
    bool enable_circleFov = false;
    bool stream_mode = false;
    bool show_esp = false;
    bool hide_top_label = false;
    bool enable_aimbot = false; // Add this line
    bool enable_bullet_tracking = false; // Add this line for bullet tracking

    int aimAssistPosition = 0;
    int circleSizeValue = 40;
    int distanceValue  = 120;
    int style_idx = 0;
    int aim_target = 0; // Add this line
    int aim_location = 0; // Add this line
    int aim_trigger = 0; // Add this line
    float colorEsp[3] = {255,255,255};
}
