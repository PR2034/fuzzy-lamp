struct Vector4
{
    float X,Y,Z,W;
    
    Vector4(float x, float y, float z, float w) {
        this->X = x;
        this->Y = y;
        this->Z = z;
        this->W = w;
    }

};