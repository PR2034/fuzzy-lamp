//
//  HeeeNoScreenShotView.h
//  HeeeNoScreenShotView-demo-OC
//
//  Created by Heee on 2021/5/18.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HeeeNoScreenShotView : UIView
- (void)setSecure:(BOOL)secure;
@end

NS_ASSUME_NONNULL_END
